/*
 * aPLib compression library  -  the smaller the better :)
 *
 * C depacker, header file
 *
 * Copyright (c) 1998-2002 by Joergen Ibsen / Jibz
 * All Rights Reserved
 */

#ifndef __DEPACK_H_INCLUDED
#define __DEPACK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/* function prototype */
unsigned int aP_depack(unsigned char *source,
                       unsigned char *destination);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __DEPACK_H_INCLUDED */
