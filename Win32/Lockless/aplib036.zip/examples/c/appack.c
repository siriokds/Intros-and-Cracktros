/*
 * aPLib compression library  -  the smaller the better :)
 *
 * C/C++ packing example
 *
 * Copyright (c) 1998-2002 by Joergen Ibsen / Jibz
 * All Rights Reserved
 */

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>

#include "aplib.h"

// compiler specific stuff
#ifdef AP_UNIX_STYLE
   #include <unistd.h>
   #define CB_CALLCONV
#else
   #include <io.h>
   #define AP_HAS_CONIO
   #ifdef AP_DLL
      #define CB_CALLCONV __stdcall
   #else
      #define CB_CALLCONV __cdecl
   #endif
#endif

#ifdef AP_HAS_CONIO
   #include <conio.h>
#endif

#ifndef O_BINARY
   #define O_BINARY 0
#endif

// possible errors
enum { OPEN_ERR = 1, READ_ERR,  SMALL_ERR,  TMP_ERR,
       PACK_ERR,     MEM_ERR,   WRITE_ERR };

// program name and version
const char *versionstr = "aPLib-Pack";

// global variables used
int infile = -1, outfile = -1;
unsigned int infilesize, outfilesize;
unsigned char *outbuffer = NULL, *inbuffer = NULL;
unsigned char *testbuffer = NULL, *workbuffer = NULL;

const unsigned char rotator[] = "-\\|/";
int rotatorpos = 0;

// =========================================================================
//  MISC. FUNCTIONS
// =========================================================================

// some I/O error handler :)
void myerror(int n)
{
   // print out error information
   printf("\n\n\007ERR: ");
   switch (n)
   {
      case OPEN_ERR  : printf("Unable to open input-file!\n"); break;
      case PACK_ERR  : printf("An error occured while packing!\n"); break;
      case READ_ERR  : printf("Unable to read from input-file!\n"); break;
      case TMP_ERR   : printf("Unable to create 'APLIBTMP.$$$'!\n"); break;
      case SMALL_ERR : printf("File is too small to pack!\n"); break;
      case MEM_ERR   : printf("Not enough memory!\n"); break;
      case WRITE_ERR : printf("Unable to write to output-file!\n"); break;
      default        : printf("An unknown error occured!\n");
   }

   // free memory and close files
   if (outbuffer != NULL) free(outbuffer);
   if (inbuffer != NULL) free(inbuffer);
   if (testbuffer != NULL) free(testbuffer);
   if (workbuffer != NULL) free(workbuffer);
   if (infile != -1) close(infile);
   if (outfile != -1) close(outfile);
   remove("APLIBTMP.$$$");

   // exit with errorlevel = error no.
   exit(n);
}

void syntax()
{
   printf("  Syntax:   appack <input file> [output file]\n\n");
}

int CB_CALLCONV callback(unsigned int inpos, unsigned int outpos)
{
   printf("\r%c Packing data                 -> %3d%%", rotator[rotatorpos], inpos * 100 / infilesize);
   rotatorpos = (rotatorpos + 1) & 0x0003;

#ifdef AP_HAS_CONIO
   // check for ESC-hit
   if (kbhit())
   {
      unsigned char ch = getch();
      if (ch == 0) ch = getch();
      if (ch == 27)
      {
         return (0); // abort packing
      }
   }
#endif

   return (1); // continue packing
}

// =========================================================================
//  MAIN
// =========================================================================

int main(int argc, char *argv[])
{
   int infilearg = 0, outfilearg = 0;

   unsigned int packedlength, an_error;

   int i;
   unsigned int j;

   // write name and copyright notice
   printf("===============================================================================\n");
   printf("%-30s  Copyright (c) 1998-2002 by Joergen Ibsen / Jibz\n", versionstr);
   printf("                                                            All Rights Reserved\n");
   printf("===============================================================================\n\n");

   // write syntax when not enough parameters
   if (argc < 2)
   {
      syntax();
      return(1);
   }

   // parse command line
   for (i = 1; i < argc; i++)
   {
      if (infilearg != 0)
      {
         if (outfilearg == 0) outfilearg = i;
      } else infilearg = i;
   }

   // print syntax if no in-file
   if (infilearg == 0)
   {
      syntax();
      return(1);
   }

   // open input file
   printf("- Opening files\n");
   if ((infile = open(argv[infilearg], O_RDONLY | O_BINARY)) == -1) myerror(OPEN_ERR);

   // get file size and check it
   infilesize = lseek(infile, 0, SEEK_END);
   if (infilesize < 64) myerror(SMALL_ERR);

   printf("   - Data size    : %u bytes\n", infilesize);

   // create tmp file
   if ((outfile = open("APLIBTMP.$$$", O_WRONLY | O_CREAT | O_BINARY | O_TRUNC, S_IREAD | S_IWRITE)) == -1) myerror(TMP_ERR);

   printf("- Allocating memory\n");
   // allocate memory for compression buffers
   if ((inbuffer = (unsigned char *) malloc(infilesize)) == NULL) myerror(MEM_ERR);
   if ((testbuffer = (unsigned char *) malloc(infilesize)) == NULL) myerror(MEM_ERR);
   if ((outbuffer = (unsigned char *) malloc(aP_max_packed_size(infilesize))) == NULL) myerror(MEM_ERR);

   // allocate work mem for the packer
   if ((workbuffer = (unsigned char *) malloc(aP_workmem_size(infilesize))) == NULL) myerror(MEM_ERR);

   // read data into memory
   lseek(infile, 0, SEEK_SET);
   read(infile, inbuffer, infilesize);

   // pack data
   if ((packedlength = aPsafe_pack(inbuffer, outbuffer, infilesize, workbuffer, callback)) == 0) myerror(PACK_ERR);

   // print out the 100% line :)
   printf("\r- Packing data                 -> %u bytes\n", packedlength);

   // write header and code to output file
   lseek(outfile, 0, SEEK_SET);
   write(outfile, outbuffer, packedlength);
   outfilesize = lseek(outfile, 0, SEEK_END);

   // depack compressed data and compare to original
   printf("- Depacking and comparing      -> ");
   printf("depacked %u bytes - ", aPsafe_depack_asm_fast(outbuffer, testbuffer));

   an_error = 0;
   for (j = 0; j < infilesize; j++) if (testbuffer[j] != inbuffer[j]) an_error = 1;

   if (an_error) printf("There were errors!\n"); else printf("Ok.\n");

   // free memory for compression buffers
   printf("- Freeing memory\n");
   if (outbuffer != NULL) free(outbuffer);
   if (inbuffer != NULL) free(inbuffer);
   if (testbuffer != NULL) free(testbuffer);
   if (workbuffer != NULL) free(workbuffer);

   // close in and out files
   printf("- Closing files\n");
   if (infile != -1) close(infile);
   if (outfile != -1) close(outfile);

   // rename the output file into the right name
   if (outfilearg != 0)
   {
      if (remove(argv[outfilearg]) != 0) if (errno == EACCES) myerror(WRITE_ERR);
      if (rename("APLIBTMP.$$$", argv[outfilearg]) != 0) myerror(WRITE_ERR);
   } else {
      printf("   - No output file specified ... writing to 'out.apk'\n");
      if (remove("out.apk") != 0) if (errno == EACCES) myerror(WRITE_ERR);
      if (rename("APLIBTMP.$$$", "out.apk") != 0) myerror(WRITE_ERR);
   }

   // print out results
   printf("\nDone ... compression ratio: %d%% ", 100 - ((outfilesize * 100) / infilesize));
   printf("(%u bytes -> %u bytes)\n", infilesize, outfilesize);

   // we're happy :)
   return (0);
}

// =========================================================================
//  END
// =========================================================================
