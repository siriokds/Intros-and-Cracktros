/*
 * aPLib compression library  -  the smaller the better :)
 *
 * C/C++ depacking example
 *
 * Copyright (c) 1998-2002 by Joergen Ibsen / Jibz
 * All Rights Reserved
 */

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>

#include "aplib.h"

// compiler specific stuff
#ifdef AP_UNIX_STYLE
   #include <unistd.h>
   #define CB_CALLCONV
#else
   #include <io.h>
   #define AP_HAS_CONIO
   #ifdef AP_DLL
      #define CB_CALLCONV __stdcall
   #else
      #define CB_CALLCONV __cdecl
   #endif
#endif

#ifdef AP_HAS_CONIO
   #include <conio.h>
#endif

#ifndef O_BINARY
   #define O_BINARY 0
#endif

// possible errors
enum { OPEN_ERR = 1, READ_ERR,  FORMAT_ERR,  TMP_ERR,
       DEPACK_ERR,   MEM_ERR,   WRITE_ERR };

// program name and version
const char *versionstr = "aPLib-Unpack";

// global variables used
int infile = -1, outfile = -1;
unsigned int infilesize, outfilesize;
unsigned char *outbuffer = NULL, *inbuffer = NULL;

// =========================================================================
//  MISC. FUNCTIONS
// =========================================================================

// some I/O error handler :)
void myerror(int n)
{
   // print out error information
   printf("\n\n\007ERR: ");
   switch (n)
   {
      case OPEN_ERR    : printf("Unable to open input-file!\n"); break;
      case DEPACK_ERR  : printf("An error occured while depacking!\n"); break;
      case READ_ERR    : printf("Unable to read from input-file!\n"); break;
      case TMP_ERR     : printf("Unable to create 'APLIBTMP.$$$'!\n"); break;
      case FORMAT_ERR  : printf("File is not packed with aPPack!\n"); break;
      case MEM_ERR     : printf("Not enough memory!\n"); break;
      case WRITE_ERR   : printf("Unable to write to output-file!\n"); break;
      default          : printf("An unknown error occured!\n");
   }

   // free memory and close files
   if (outbuffer != NULL) free(outbuffer);
   if (inbuffer != NULL) free(inbuffer);
   if (infile != -1) close(infile);
   if (outfile != -1) close(outfile);
   remove("APLIBTMP.$$$");

   // exit with errorlevel = error no.
   exit(n);
}

void syntax()
{
   printf("  Syntax:   apunpack <input file> [output file]\n\n");
}

// =========================================================================
//  MAIN
// =========================================================================

int main(int argc, char *argv[])
{
   int infilearg = 0, outfilearg = 0;

   unsigned int depackedlength;

   int i;

   // write name and copyright notice
   printf("===============================================================================\n");
   printf("%-30s  Copyright (c) 1998-2002 by Joergen Ibsen / Jibz\n", versionstr);
   printf("                                                            All Rights Reserved\n");
   printf("===============================================================================\n\n");

   // write syntax when not enough parameters
   if (argc < 2)
   {
      syntax();
      return(1);
   }

   // parse command line
   for (i = 1; i < argc; i++)
   {
      if (infilearg != 0)
      {
         if (outfilearg == 0) outfilearg = i;
      } else infilearg = i;
   }

   // print syntax if no in-file
   if (infilearg == 0)
   {
      syntax();
      return(1);
   }

   // open input file
   printf("- Opening files\n");
   if ((infile = open(argv[infilearg], O_RDONLY | O_BINARY)) == -1) myerror(OPEN_ERR);

   // get file size and check it
   infilesize = lseek(infile, 0, SEEK_END);
   if (infilesize < 64) myerror(FORMAT_ERR);

   // allocate memory for input buffer
   if ((inbuffer = (unsigned char *) malloc(infilesize)) == NULL) myerror(MEM_ERR);

   // read file
   lseek(infile, 0, SEEK_SET);
   read(infile, inbuffer, infilesize);

   // get depacked size from header
   depackedlength = aPsafe_get_orig_size(inbuffer);

   if (depackedlength == 0) myerror(FORMAT_ERR);

   // allocate memory for output buffer
   if ((outbuffer = (unsigned char *) malloc(depackedlength)) == NULL) myerror(MEM_ERR);

   // create tmp file
   if ((outfile = open("APLIBTMP.$$$", O_WRONLY | O_CREAT | O_BINARY | O_TRUNC, S_IREAD | S_IWRITE)) == -1) myerror(TMP_ERR);

   // depack compressed data
   printf("- Depacking                    -> ");
   if (aPsafe_depack_asm_fast(inbuffer, outbuffer) != depackedlength) myerror(DEPACK_ERR);
   printf("depacked %u bytes\n", depackedlength);

   // write code to output file
   lseek(outfile, 0, SEEK_SET);
   write(outfile, outbuffer, depackedlength);
   outfilesize = lseek(outfile, 0, SEEK_END);

   // free memory for compression buffers
   printf("- Freeing memory\n");
   if (outbuffer != NULL) free(outbuffer);
   if (inbuffer != NULL) free(inbuffer);

   // close in and out files
   printf("- Closing files\n");
   if (infile != -1) close(infile);
   if (outfile != -1) close(outfile);

   // rename the output file into the right name
   if (outfilearg != 0)
   {
      if (remove(argv[outfilearg]) != 0) if (errno == EACCES) myerror(WRITE_ERR);
      if (rename("APLIBTMP.$$$", argv[outfilearg]) != 0) myerror(WRITE_ERR);
   } else {
      printf("   - No output file specified ... writing to 'out.dat'\n");
      if (remove("out.dat") != 0) if (errno == EACCES) myerror(WRITE_ERR);
      if (rename("APLIBTMP.$$$", "out.dat") != 0) myerror(WRITE_ERR);
   }

   // print out done
   printf("\nDone\n");

   // we're happy :)
   return (0);
}

// =========================================================================
//  END
// =========================================================================
