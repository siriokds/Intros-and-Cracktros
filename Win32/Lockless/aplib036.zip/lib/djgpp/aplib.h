/*
 * aPLib compression library  -  the smaller the better :)
 *
 * DJGPP header file
 *
 * Copyright (c) 1998-2002 by Joergen Ibsen / Jibz
 * All Rights Reserved
 */

#ifndef __APLIB_H_INCLUDED
#define __APLIB_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

unsigned int aP_pack(unsigned char *source,
                     unsigned char *destination,
                     unsigned int length,
                     unsigned char *workmem,
                     int (*callback) (unsigned int, unsigned int));

unsigned int aP_workmem_size(unsigned int inputsize);

unsigned int aP_max_packed_size(unsigned int inputsize);

unsigned int aP_depack_asm(unsigned char *source, unsigned char *destination);

unsigned int aP_depack_asm_fast(unsigned char *source, unsigned char *destination);

unsigned int aP_crc32(unsigned char *source, unsigned int length);

unsigned int aPsafe_pack(unsigned char *source,
                         unsigned char *destination,
                         unsigned int length,
                         unsigned char *workmem,
                         int (*callback) (unsigned int, unsigned int));

unsigned int aPsafe_check(unsigned char *source);

unsigned int aPsafe_get_orig_size(unsigned char *source);

unsigned int aPsafe_depack_asm(unsigned char *source, unsigned char *destination);

unsigned int aPsafe_depack_asm_fast(unsigned char *source, unsigned char *destination);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __APLIB_H_INCLUDED */
