/*
 * aPLib compression library  -  the smaller the better :)
 *
 * DLL header file
 *
 * Copyright (c) 1998-2002 by Joergen Ibsen / Jibz
 * All Rights Reserved
 */

#ifndef __APLIB_H_INCLUDED
#define __APLIB_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

__declspec(dllimport) unsigned int __stdcall aP_pack(unsigned char *source,
                             unsigned char *destination,
                             unsigned int length,
                             unsigned char *workmem,
                             int (__stdcall *callback) (unsigned int, unsigned int));

__declspec(dllimport) unsigned int __stdcall aP_workmem_size(unsigned int inputsize);

__declspec(dllimport) unsigned int __stdcall aP_max_packed_size(unsigned int inputsize);

__declspec(dllimport) unsigned int __stdcall aP_depack_asm(unsigned char *source, unsigned char *destination);

__declspec(dllimport) unsigned int __stdcall aP_depack_asm_fast(unsigned char *source, unsigned char *destination);

__declspec(dllimport) unsigned int __stdcall aP_crc32(unsigned char *source, unsigned int length);

__declspec(dllimport) unsigned int __stdcall aPsafe_pack(unsigned char *source,
                             unsigned char *destination,
                             unsigned int length,
                             unsigned char *workmem,
                             int (__stdcall *callback) (unsigned int, unsigned int));

__declspec(dllimport) unsigned int __stdcall aPsafe_check(unsigned char *source);

__declspec(dllimport) unsigned int __stdcall aPsafe_get_orig_size(unsigned char *source);

__declspec(dllimport) unsigned int __stdcall aPsafe_depack_asm(unsigned char *source, unsigned char *destination);

__declspec(dllimport) unsigned int __stdcall aPsafe_depack_asm_fast(unsigned char *source, unsigned char *destination);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* __APLIB_H_INCLUDED */
