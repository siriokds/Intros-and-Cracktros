- This is the DLL version of aPLib.

- You will propably have to edit the APLIB.H file to get it to work
  with your compiler/linker.

- APLIB.LIB is an import library for Visual C++.

- It works fine as a .wdl file for WDOSX -- just rename it!
